﻿using System.Xml.Linq;
namespace Vertaling_tool.Data
{
    public static class TranslationService
    {
        private static bool resourceRed = false;
        public class Translation
        {
            public string Code { get; set; }
            public List<string> Translations { get; set; }
        }
        public class resourceElem
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }

        public static List<string> Languages = null;
        public static List<string> Resources = new List<string>();
        public static Dictionary<string, List<resourceElem>> Translations = null;
        public static List<Translation> Translationsgrid = null;

        public static void ReadResources(string folder)
        {
            if (resourceRed) return;
            
            Resources = new List<string>();
            Translations = new ();
            Translationsgrid = new ();
            Languages = new() { "Standaard" };
            bool missingFound = false;

            // Haalt de data uit Resource.resx
            string[] files = Directory.GetFiles(folder, "resource.resx");
            
            if (files.Length == 1)
            {
                var elementen = xmlread(files[0]);
                
                files = Directory.GetFiles(folder, "Missing.xml");
                if (files.Length == 1)
                {
                    var missing = xmlread(files[0]);

                    foreach(var e in missing)
                    {
                        if(elementen.Find(el=>el.Name == e.Name) == null)
                        {
                            elementen.Add(e);
                            missingFound = true;
                        }
                    }
                } 
                
                foreach (var elem in elementen)
                {
                    Translationsgrid.Add(new Translation() { Code = elem.Name, Translations = new List<string>() { elem.Value } });
                }

                // Variable talen files openen.
                files = Directory.GetFiles(folder, "resource.*.resx");
                foreach (var file in files)
                {
                    var taal = file.Split('.')[1];
                    if (taal != "nl-NL")
                    {
                        Languages.Add(taal);
                        var elementen2 = xmlread(file);

                        foreach (var elem in elementen)
                        {
                            var elem2 = elementen2.Find(e => e.Name == elem.Name);
                            if (elem2 == null)
                            {
                                elem2 = new resourceElem { Name = elem.Name, Value = elem.Value };
                                elementen2.Add(elem2);
                            }
                            var t = Translationsgrid.Find(e => e.Code == elem.Name);
                            t?.Translations.Add(elem2.Value);
                        }
                    }
                }
                resourceRed = true;

                Backup("files");
                if (missingFound)
                {
                    SaveTranslations(Translationsgrid);
                }
                // Verwijder missing file
                File.Delete(@"resources/Missing.xml");
            }
        }

        // Functie voor Xml opslag
        public static void SaveTranslations(List<Translation> translationsgrid)
        {
            for(int i=0; i < Languages.Count;i++)
            {
                string l = Languages[i]; 
                // Option1: Using SetAttributeValue()
                XDocument xdoc = XDocument.Load("bron_resources.xml");

                XElement? root = xdoc.Element("root");
                if(root != null)
                {
                    foreach (Translation t in translationsgrid)
                    {
                        XElement elem = new("data");
                        elem.Add(new XAttribute("name", t.Code));
                        elem.Add(new XAttribute(XNamespace.Xml + "space", "preserve"));
                        elem.SetElementValue("value", t.Translations[i]);
                        root.Add(elem);
                    }
                    if (l == "Standaard")
                        xdoc.Save("resources/resource.resx");
                    else
                        xdoc.Save($"resources/resource.{l}.resx");
                }
            }
        }

        // Functie voor xml lezen
        private static List<resourceElem> xmlread(string file)
        {
            XDocument xdoc = XDocument.Load(file);
            return xdoc.Descendants("data")
            .Select(data => new resourceElem
            {
                Name = data.Attribute("name").Value,
                Value = data.Element("value").Value
            }).ToList();
        }

        // Backup functie. Dit slaat de bestanden op in backup. dit word elke keer gedaan bij het opstarten.
        public static void Backup(string folder)
        {
            for (int i = 0; i < Languages.Count; i++)
            {
                string l = Languages[i];
                string xml = File.ReadAllText("resources/resource.resx");
                string path = $"resources.backup/resource.{l}.resx";
                File.Copy("resources/resource.resx", path, true);
                TextWriter tw = new StreamWriter(path);
                tw.WriteLine(xml);
                tw.Close();
                File.WriteAllText("resources/resource.resx", xml);
            }
        }
    }
}